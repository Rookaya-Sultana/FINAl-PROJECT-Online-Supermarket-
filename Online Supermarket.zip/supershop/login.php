<html>  
<head>  
    <title>Login</title>    
    <link rel = "stylesheet" type = "text/css" href = "phpcss.css">   
</head>

<body>
<div class = "box">  
<h1>Login</h1>
<form action="" method="post" class="login-form">
<div class="textbox">
        
        <i  class="fas fa-user "></i>
        <input type="email"   name="email" id="email" placeholder="Email" required> <br>
</div>

<div class="textbox">

<i  class="fas fa-lock "></i>
        <input type="password"  name="password" id="pass" placeholder="Password" required><br>
</div>

        <input type="submit" name="login" id="login"  class="btn" required><br>

        <a href="signin.php">Registration</a> <br>

</div> 
</form>
</body>
</html>

<?php
session_start();
error_reporting(0);

include "connection.php";

if (isset($_POST['login'])) {

        // user data post
        $email = $_POST['email'];
        $pass = $_POST['password'];

        $ch1 =  "SELECT email FROM users where email = '$email' ";
        $ch2 =  "SELECT password FROM users where password = '$pass' ";
// query connect korche and execute korche
        $emailchk =mysqli_query($connect,$ch1);
        $passchk =mysqli_query($connect,$ch2);

//emain abd pass e data tule anche
        $r1 = mysqli_fetch_array($emailchk);
        $r2 = mysqli_fetch_array($passchk);
        if($r1['email'] == $email &&  $r2['password'] == $pass)
        {
                $_SESSION['email']=$r1['email'];
                header('Location: home.php');
                exit();
        }
        else{
                echo'<link rel = "stylesheet" type = "text/css" href = "style11.css">' ;
                echo nl2br ("Login Failed.\nInvalid password",false);
               
        }
        
        
}

?>


 